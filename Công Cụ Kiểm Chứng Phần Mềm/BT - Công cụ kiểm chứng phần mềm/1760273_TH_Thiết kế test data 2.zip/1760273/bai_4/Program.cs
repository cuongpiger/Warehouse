using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Class4 b4 = new Class4();

            b4.Input();
            b4.Output();
        }
    }
}
