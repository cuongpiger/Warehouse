using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Class5 b5 = new Class5();

            b5.Input();
            b5.Output();
        }
    }
}