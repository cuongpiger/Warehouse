using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Class2 b2 = new Class2();

            b2.Input();
            b2.Output();
        }
    }
}
