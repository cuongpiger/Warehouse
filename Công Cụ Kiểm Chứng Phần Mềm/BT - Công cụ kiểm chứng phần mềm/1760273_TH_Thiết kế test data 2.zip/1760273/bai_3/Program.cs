using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Class3 b3 = new Class3();

            b3.Input();
            b3.Output();
        }
    }
}
