﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static _1760273.ReplaceAction;

namespace _1760273
{
    static class StringExtension
    {
        public static bool IsEmpty(this string line)
        {
            return line.Length == 0;
        }
    }

    delegate string StringProcessor(string origin, StringProcessorArgs args);
    class StringProcessorArgs { }

    interface Action
    {
        string Name { get; }
        StringProcessor Processor { get;}
        StringProcessorArgs Args { get; set; }

    }

    class ReplaceAction : Action
    {
        public string Name => "The seeker";

        public StringProcessor Processor => replace;

        public StringProcessorArgs Args { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        static string replace(string origin, StringProcessorArgs args)
        {
            var myArgs = args as ReplaceStringProcessorArgs;
            var needle = myArgs.Needle;
            var hammer = myArgs.Hammer;

            return origin.Replace(needle, hammer);
        }

        public class ReplaceStringProcessorArgs: StringProcessorArgs
        {
            public string Needle { get; set; }
            public string Hammer { get; set; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string headers = String.Format("{0, 10} {2, 10} {2, 10} {1, 10} {3, 10}", "City", "Year", "Population", "Change");
            Console.WriteLine(headers);

            string haystack = "The quick brown fox jumps over the lazy dog";
            string needle = "brown";

            if (haystack.Contains(needle)) // tìm chuổi con needle có xuất hiện trong chuổi mẹ haystack hay ko
            {
                Console.WriteLine("Found");
            }

            int position = haystack.IndexOf(needle); // trả về index lần đầu tiên xuất hiện của needle
            int reversePos = haystack.LastIndexOf(needle); // trả về index cuối cùng xuất hiện của needle

            //bool isEmpty = StringExtension.IsEmpty(haystack);
            /*Viết như thế này nếu như hàm IsEmpty được viết như sau:
             
              public static bool IsEmpty(string line)
              {
                  return line.Length == 0;
              }

            */

            bool isEmpty = haystack.IsEmpty();

            string number = "149abc";
            //try
            //{

            //    int value = int.Parse(number);

            //    Console.Write(value + 14);
            //} catch (Exception ex)
            //{
            //    Console.WriteLine("There is an error occur when trying to convert sting {0} into number: {1}", number, ex.Message);
            //}

            int value = 0;
            bool result = int.TryParse(number, out value);

            if (result)
            {
                Console.Write(value + 14);
            }
            else
            {
                Console.WriteLine("Cannot perform operation. Please check input");
            }

            string alteredString = haystack.Remove(3, 10);
            Console.WriteLine(alteredString);
            string replaced = haystack.Replace("w", "m");
            Console.WriteLine(replaced);

            string file1 = "unsplash - Anatoly - 1920x1080.jpg";
            string file2 = "unsplash - Nguyen Viet Hung - 1920x1080.jpg";
            string file3 = "unsplash - Thang Soi - 1920x1080.jpg";

            ReplaceAction action = new ReplaceAction();

            Console.WriteLine(action.Processor(file1, new ReplaceStringProcessorArgs() {
                Needle = "unsplash",
                Hammer = "vuatrom"
            }));
        }
    }
}
