using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project03
{
    class Program
    {
        static void Main(string[] args)
        {
            // phương trình vô ngiệm
            project03 p1 = new project03(0, 0, 69);
            p1.solveProblem();

            // phương trình có vô số nghiệm
            project03 p2 = new project03(0, 0, 0);
            p2.solveProblem();

            // Phuong trinh co duy nhat mot nghiem x
            project03 p3 = new project03(0, 69, 96);
            p3.solveProblem();

            // Phuong trinh co hai nghiem phan biet
            project03 p4 = new project03(1, 5, 5);
            p4.solveProblem();

            // Phuong trinh co nghiem kep x
            project03 p5 = new project03(2, 4, 2);
            p5.solveProblem();

            project03 p6 = new project03(6, 2, 9);
            p6.solveProblem();
        }
    }
}
