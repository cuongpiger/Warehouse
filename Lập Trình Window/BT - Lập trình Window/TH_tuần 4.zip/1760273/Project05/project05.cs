﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project05
{
    class project05
    {
        private int ngay, thang, nam;

        public void createDate()
        {
            int[] month = { -1, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            Random r = new Random();

            ngay = r.Next(1, 32);
            thang = r.Next(1, 13);
            nam = r.Next(1900, 2101);

            if (this.isLeapYear() == true)
            {
                ++month[2];
            }

            if (ngay > month[thang])
            {
                this.createDate();
            }
            else
            {
                return;
            }
        }

        public bool isLeapYear()
        {
            return (((nam % 4 == 0) && (nam % 100 != 0)) || (nam % 400 == 0));
        }

        public void printNextDate()
        {
            int ngaysau = ngay, thangsau = thang, namsau = nam;

            int[] month = { -1, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

            if (this.isLeapYear() == true)
            {
                ++month[2];
            }

            ++ngaysau;

            if (ngaysau > month[thang])
            {
                ngaysau = 1;
                ++thangsau;

                if (thangsau > 12)
                {
                    thangsau = 1;
                    ++namsau;
                }
            }

            Console.WriteLine("Hom nay: {0}/{1}/{2}", ngay, thang, nam);
            Console.WriteLine("Ngay mai: {0}/{1}/{2}", ngaysau, thangsau, namsau);
        }
    }
}
