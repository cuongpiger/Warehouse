using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project05
{
    class Program
    {
        static void Main(string[] args)
        {
            project05 d = new project05();
            d.createDate();
            d.printNextDate();
        }
    }
}
