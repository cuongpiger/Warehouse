using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project01
{
    class Program
    {
        static void Main(string[] args)
        {
            project01 t = new project01();
            t.convertC();
        }
    }
}
