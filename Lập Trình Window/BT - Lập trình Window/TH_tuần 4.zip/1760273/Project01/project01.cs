﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project01
{
    class project01
    {
        private double f;

        public void convertC()
        {
            Random r = new Random();

            f = r.Next(1000000000);
            double c = 5.0 / 9.0 * (f - 32);

            Console.WriteLine("Do F: {0}", f);
            Console.WriteLine("Do C: {0}", c);
        }
    }
}
