using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project04
{
    class Program
    {
        static void Main(string[] args)
        {
            project04 x = new project04();
            x.solve();
        }
    }
}
