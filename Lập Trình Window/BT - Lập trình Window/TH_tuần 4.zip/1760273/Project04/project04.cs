﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project04
{
    class project04
    {
        private double costPhone;

        public void solve()
        {
            Console.Write("Nhap gia tien dien thoai: ");
            costPhone = double.Parse(Console.ReadLine());

            double res = costPhone / 6.0;
            Console.WriteLine("So tien moi thang Hung phai tra trong 6 thang: {0}", res);
        }
    }
}
