﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project02
{
    class project02
    {
        private double a, b;

        public project02(double A, double B)
        {
            a = A;
            b = B;
        }

        public void solveProblem()
        {
            if (a == 0)
            {
                if (b == 0)
                {
                    Console.WriteLine("Phuong trinh co vo so nghiem");
                }
                else
                {
                    Console.WriteLine("Phuong trinh vo nghiem");
                }
            }
            else
            {
                double res = -b / a;
                Console.WriteLine("Phuong trinh co nghiem la: {0}", res);
            }
        }
    }
}
