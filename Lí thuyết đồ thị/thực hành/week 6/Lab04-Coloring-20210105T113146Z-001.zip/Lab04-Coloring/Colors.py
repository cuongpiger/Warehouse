#color
default_color = 'grey'
current_color = 'orange'
visited_color = 'deepskyblue'
path_node_color = 'lime'
queue_color='violet'
path_color = 'red'
dep_color='lightgreen'
des_color='lightgreen'