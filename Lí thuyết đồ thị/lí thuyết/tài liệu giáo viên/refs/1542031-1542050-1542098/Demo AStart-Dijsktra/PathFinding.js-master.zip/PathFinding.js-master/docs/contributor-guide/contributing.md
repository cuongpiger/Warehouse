If you have added a new feature or fixed a bug please open a pull request.

Don't forget to add yourself to the 
[list of contributors](https://github.com/qiao/PathFinding.js/blob/master/docs/contributor-guide/authors.md).